from django.apps import AppConfig


class AuthenConfig(AppConfig):
    name = 'authen'